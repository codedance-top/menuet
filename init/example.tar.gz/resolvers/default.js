'use strict';

/**
 * 设置正常返回结果。
 *
 * @param {ServerResponse} res HTTP 响应实例
 * @param {object} data 返回数据
 * @returns {Promise.<object>}
 */
module.exports = async (res, data) => {

  let req = res.req;

  if (req.method === 'POST') {
    res.statusCode = 201;
  }

  return { data };
};

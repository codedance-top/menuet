'use strict';

const promisify = require('util').promisify;
const mkdirp = promisify(require('mkdirp'));
const path = require('path');

/**
 * 初始化应用。
 *
 * @param {object} UserService 用户服务
 */
module.exports = async (UserService) => {

  // 创建上传文件输出路径
  await mkdirp(path.join(process.env.PWD, 'public/files'));

  // 创建管理员用户账号
  try {

    await UserService.create({
      name: '管理员',
      type: 'admin',
      username: 'admin',
      password: 'admin'
    });

  } catch (e) {

    if (!(e.name === 'MongoError' && e.code === 11000)) {
      throw e;
    }

  }

};

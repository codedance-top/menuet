'use strict';

const USER_INFO = Symbol.for('x-user-info');

/**
 * 检查访问令牌是否有效。
 * 访问令牌通过 Authorization 请求头传递，格式为“Bearer 访问令牌”。
 *
 * @see https://jwt.io/introduction/
 * @param {IncomingMessage} req HTTP 请求
 * @param {object} options 拦截器配置参数
 * @param {object} Errors 错误类定义命名空间
 * @param {object} UserService 用户服务
 * @returns {object} 访问令牌中的用户信息
 */
module.exports = async (req, options, Errors, UserService) => {

  let accessToken = ((req.get('authorization') || '').match(/^Bearer (.+)$/) || [])[1];

  if (!accessToken) {
    throw new Errors.UnauthorizedError('尚未登录');
  }

  req[USER_INFO] = await UserService.verifyAccessToken(accessToken);
};

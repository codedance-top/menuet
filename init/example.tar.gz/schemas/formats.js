'use strict';

/**
 * JSON schema 扩展 format 定义。
 *
 * @see https://github.com/epoberezkin/ajv#api-addformat
 * @type {object}
 */
module.exports = {
  objectId: /^[0-9a-f]{24}$/i,
  name: /^$/,
  username: /^[a-z]([_\-]?[0-9a-z]+)+$/i
};

'use strict';

/**
 * JSON schema 扩展 keyword 定义。
 *
 * 输出数组的每一个元素定义一个 JSON schema 的 keyword。
 *
 * compile 函数将接收以下几个参数：
 *   • schema：字段的数据模式定义
 *   • parentSchema：字段所属对象的数据模式定义
 *   • rootSchema：最上级数据模式定义
 *
 * AJV 将通过执行 compile 函数得到一个校验函数，该函数接收以下几个参数：
 *   • value：校验字段的值
 *   • path：校验字段在最上级对象中的路径
 *   • parent：字段所属对象
 *   • key：字段在所属对象中的名称
 *   • root：最上级对象
 *
 * 通过校验时该函数返回 true，否则返回 false。
 *
 * @see https://github.com/epoberezkin/ajv#defining-custom-keywords
 * @type {object}
 */
module.exports = {

  toISODateString: {
    modifying: true,
    schema: false,
    valid: true,
    errors: false,
    validate: (value, path, parent, key) => {
      if (value instanceof Date && parent) {
        parent[key] = value.toISOString();
      }
    }
  }

};

'use strict';

/**
 * 返回错误类。
 *
 * @returns {{
 *   AuthenticationError: function,
 *   UnauthorizedError: function
 * }}
 */
module.exports = () => {

  /**
   * 登录认证失败错误。
   * @extends {Error}
   */
  class AuthenticationError extends Error {
    constructor(message) {
      super(message);
      this.name = 'AuthenticationError';
      this.statusCode = 401;
    }
  }

  /**
   * 未登录错误。
   * @extends {Error}
   */
  class UnauthorizedError extends Error {
    constructor(message) {
      super(message);
      this.name = 'UnauthorizedError';
      this.statusCode = 401;
    }
  }

  return {
    AuthenticationError,
    UnauthorizedError
  };

};

module.exports[Symbol.for('moduleName')] = 'Errors';
